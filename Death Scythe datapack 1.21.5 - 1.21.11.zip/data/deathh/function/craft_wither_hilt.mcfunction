kill @e[type=item,nbt={Item:{id:"minecraft:netherite_ingot",count:2}},limit=1,sort=nearest]
kill @e[type=item,nbt={Item:{id:"minecraft:nether_star",count:1}},limit=1,sort=nearest]
kill @e[type=item,nbt={Item:{id:"minecraft:wither_rose",count:6}},limit=1,sort=nearest]
summon item ~ ~ ~ {Item:{id:"minecraft:glistering_melon_slice",count:1,components:{"minecraft:item_model":"deathhh:wither_hilt","minecraft:item_name":{"bold":true,"color":"dark_purple","italic":true,"text":"Wither Hilt","underlined":true},"minecraft:damage_resistant":{types:"#minecraft:is_fire"}}}}
playsound block.anvil.use block @a[distance=..10]
playsound entity.wither.ambient block @a[distance=..10]
