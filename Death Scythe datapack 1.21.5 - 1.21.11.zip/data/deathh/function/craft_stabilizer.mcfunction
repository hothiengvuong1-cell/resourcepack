kill @e[type=item,nbt={Item:{id:"minecraft:diamond_block",count:5}},limit=1,sort=nearest]
kill @e[type=item,nbt={Item:{id:"minecraft:netherite_ingot",count:4}},limit=1,sort=nearest]
summon item ~ ~ ~ {Item:{id:"minecraft:glistering_melon_slice",count:1,components:{"minecraft:item_model":"deathhh:stabilizer","minecraft:item_name":{"bold":true,"color":"blue","italic":true,"text":"Stabilizer","underlined":true},"minecraft:damage_resistant":{types:"#minecraft:is_fire"}}}}
playsound block.conduit.activate block @a[distance=..10]
