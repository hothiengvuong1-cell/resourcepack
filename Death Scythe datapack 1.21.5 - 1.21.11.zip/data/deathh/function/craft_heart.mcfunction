kill @e[type=item,nbt={Item:{id:"minecraft:netherite_ingot",count:1}},limit=1,sort=nearest]
kill @e[type=item,nbt={Item:{id:"minecraft:nether_star",count:4}},limit=1,sort=nearest]
kill @e[type=item,nbt={Item:{id:"minecraft:diamond_block",count:4}},limit=1,sort=nearest]
summon item ~ ~ ~ {Item:{id:"minecraft:glistering_melon_slice",count:1,components:{"minecraft:item_model":"deathhh:corrupted_heart","minecraft:item_name":{"bold":true,"color":"dark_purple","italic":true,"text":"Corrupted Nether Heart","underlined":true},"minecraft:damage_resistant":{types:"#minecraft:is_fire"}}}}
playsound entity.wither.death block @a[distance=..10]
