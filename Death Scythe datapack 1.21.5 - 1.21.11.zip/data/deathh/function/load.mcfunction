
scoreboard objectives add hit minecraft.custom:minecraft.damage_dealt
scoreboard objectives add hurt_time dummy
