# Detecta se a entidade atingida é uma foice com a tag 'profile_1'
execute as @a[nbt={SelectedItem:{id:"minecraft:golden_sword",components:{"minecraft:item_model":"deathhh:scythe_3d"}}}] at @s as @s[scores={hit=1..}] run function deathh:apply_wither
execute as @a[nbt={SelectedItem:{id:"minecraft:golden_sword",components:{"minecraft:item_model":"deathhh:scythe_3d"}}}] run effect clear @s wither 
scoreboard players reset @a hit 

