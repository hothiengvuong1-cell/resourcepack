
execute as @e[type=player] store result score @s hurt_time run data get entity @s HurtTime
execute as @e[type=!player] store result score @s hurt_time run data get entity @s HurtTime
execute as @e[scores={hurt_time=1..},distance=..5] run tag @s add damaged_by_player
execute as @e[tag=damaged_by_player] run effect give @s minecraft:wither 5 2 true
tag @e[tag=damaged_by_player] remove damaged_by_player
