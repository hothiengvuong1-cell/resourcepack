kill @e[type=item,nbt={Item:{id:"minecraft:glistering_melon_slice",count:4,components:{"minecraft:item_model":"deathhh:decay_essence"}}},limit=1,sort=nearest]
kill @e[type=item,nbt={Item:{id:"minecraft:nether_star",count:1}},limit=1,sort=nearest]
kill @e[type=item,nbt={Item:{id:"minecraft:wither_skeleton_skull",count:4}},limit=1,sort=nearest]
summon item ~ ~ ~ {Item:{id:"minecraft:glistering_melon_slice",count:1,components:{"minecraft:item_model":"deathhh:wither_poison","minecraft:item_name":{"bold":true,"color":"dark_purple","italic":true,"text":"Wither Poison","underlined":true},"minecraft:damage_resistant":{types:"#minecraft:is_fire"}}}}
playsound block.anvil.use block @a[distance=..10]
playsound entity.wither.ambient block @a[distance=..10]
