kill @e[type=item,nbt={Item:{id:"minecraft:wither_rose",count:8}},limit=1,sort=nearest]
kill @e[type=item,nbt={Item:{id:"minecraft:wither_skeleton_skull",count:1}},limit=1,sort=nearest]
summon item ~ ~ ~ {Item:{id:"minecraft:glistering_melon_slice",count:1,components:{"minecraft:item_model":"deathhh:decay_essence","minecraft:item_name":{"bold":true,"color":"dark_purple","italic":true,"text":"Decay Essence","underlined":true}}}}
playsound entity.wither.shoot block @a[distance=..10]
