execute unless predicate rapiers:looking_at_interactable unless score @s rapiers.sprint matches 1.. unless entity @n[type=interaction,tag=rapiers.stance,distance=..0.1] run return run summon interaction ~ ~ ~ {width:0.6,height:1.8,Tags:["rapiers.stance"]}
execute if score @s rapiers.sprint matches 1.. run return run scoreboard players remove @s rapiers.sprint 1
execute as @n[type=interaction,tag=rapiers.stance,distance=..0.1] on target run scoreboard players set @s rapiers.sprint 3
execute if predicate rapiers:looking_at_interactable run return run kill @n[type=interaction,tag=rapiers.stance,distance=..0.1]
execute unless score @s rapiers.sprint matches 1..3 run schedule function rapiers:reset 2t replace