advancement revoke @s only rapiers:tick
execute if predicate rapiers:standing_still run function rapiers:stance
execute if predicate rapiers:sprinting store result score @s rapiers.sprint run data get entity @s SelectedItem.components."minecraft:swing_animation".duration
execute if predicate rapiers:sprinting_or_standing_still run return run item modify entity @s weapon.mainhand rapiers:rapier_on
execute unless score @s rapiers.sprint matches ..0 run return run scoreboard players remove @s rapiers.sprint 1
item modify entity @s weapon.mainhand rapiers:rapier_off