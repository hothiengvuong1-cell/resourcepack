execute as @a[tag=rapiers.craft_netherite_rapier] run function rapiers:fix_netherite_rapier
