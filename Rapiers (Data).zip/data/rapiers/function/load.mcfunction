advancement revoke @a only rapiers:tick
scoreboard objectives add rapiers.sprint dummy