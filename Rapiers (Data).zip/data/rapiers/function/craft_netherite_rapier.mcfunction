item modify entity @s player.cursor rapiers:netherite_rapier
tag @s add rapiers.craft_netherite_rapier
schedule function rapiers:detect_netherite_rapier 1t
advancement revoke @s only rapiers:craft_netherite_rapier
