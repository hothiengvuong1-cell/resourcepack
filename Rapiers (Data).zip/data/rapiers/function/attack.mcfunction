execute store result score @s rapiers.sprint run data get entity @s SelectedItem.components."minecraft:swing_animation".duration
advancement revoke @s only rapiers:rapier_attack